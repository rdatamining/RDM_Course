Author:  Yanchang Zhao
Email:   yanchang@RDataMining.com
Twitter: @RDataMining
Website: http://www.RDataMining.com
Date:    July 2019

This ZIP archive provides all datasets, slides and scripts for the R and Data Mining course.

Instructions:
1. Open the .Rproj file with RStudio
2. Run 'Install-R-packages.R' (in folder 'code') to install the required R packages 
3. Open a tutorial PDF file (in folder 'docs') and its corresponding R script file (in folder 'code') to learn it

Please feel free to let me know if any comments or suggestions. Thanks!